Tải node_modules mới chạy được nhé 
cd đến đường dẫn của file: npm install